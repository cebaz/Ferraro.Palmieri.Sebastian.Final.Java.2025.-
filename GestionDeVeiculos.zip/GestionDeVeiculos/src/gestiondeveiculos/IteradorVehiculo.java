package gestiondeveiculos;

import java.util.Iterator;
import java.util.List;

public class IteradorVehiculo implements Iterator<Vehiculo> {

    private List<Vehiculo> lista;
    private int posicion;

    public IteradorVehiculo(List<Vehiculo> lista) {
        this.lista = lista;
        this.posicion = 0;
    }

    @Override
    public boolean hasNext() {
        return posicion < lista.size();
    }

    @Override
    public Vehiculo next() {
        return lista.get(posicion++);
    }
}
