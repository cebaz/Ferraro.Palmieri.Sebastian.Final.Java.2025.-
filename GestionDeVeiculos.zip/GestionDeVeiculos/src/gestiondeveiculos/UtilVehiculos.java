package gestiondeveiculos;
import gestiondeveiculos.Enums.EstadoVehiculo;
import java.util.ArrayList;
import java.util.List;

public class UtilVehiculos {

    // Wildcard con límite inferior
    public static void agregarVehiculo(List<? super Vehiculo> lista, Vehiculo v) {

        lista.add(v);
    }
    
    public static List<Vehiculo> filtrarPorEstado(List<? extends Vehiculo> lista, EstadoVehiculo estado) {

        List<Vehiculo> resultado = new ArrayList<>();

        for (Vehiculo v : lista) {
            if (v.getEstado() == estado) {
                resultado.add(v);
            }
        }
        return resultado;
    }
}