package gestiondeveiculos;

import gestiondeveiculos.Interfaces.Crud;
import gestiondeveiculos.Interfaces.Modificador;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import gestiondeveiculos.Excepciones;

public class GestionDeVeiculos<T extends Vehiculo> implements Crud<T> {

    private List<T> vehiculos;

    public static void agregarVehiculo(List<? super Vehiculo> lista, Vehiculo v){
        lista.add(v);
    }
    
    public GestionDeVeiculos() {
        vehiculos = new ArrayList<>();
    }
    
    public void ordenarNatural() {
        Collections.sort(vehiculos);
    }

    public void ordenarConComparator(Comparator<T> comp) {
        Collections.sort(vehiculos, comp);
    }
    
    public void aplicarModificacion(Modificador<T> mod) {
        for (T v : vehiculos) {
            mod.aplicar(v);
        }
    }

    public void aplicarConsumer(java.util.function.Consumer<T> consumer) {
        for (T v : vehiculos) {
            consumer.accept(v);
        }
    }
    
    public void reemplazarLista(List<T> nueva){
        vehiculos.clear();
        vehiculos.addAll(nueva);
    }

    @Override
    public void agregar(T elemento) {
        vehiculos.add(elemento);
    }

    @Override
    public void eliminar(int id) {
        Iterator<T> it = vehiculos.iterator();
        while (it.hasNext()) {
            T v = it.next();
            if (v.getId() == id) {
                it.remove();
                return;
            }
        }
        throw new Excepciones.VehiculoNoEncontradoException(id);
    }

    @Override
    public T buscar(int id) {
        for (T v : vehiculos) {
            if (v.getId() == id) {
                return v;
            }
        }
        throw new Excepciones.VehiculoNoEncontradoException(id);
    }

    @Override
    public List<T> listar() {
        return vehiculos;
    }

    public Iterator<Vehiculo> iteratorPersonalizado() {
        return new IteradorVehiculo((List<Vehiculo>) vehiculos);
    }
    
    //Comparadores
    public static class ComparadorPorMarca implements Comparator<Vehiculo> {

        @Override
        public int compare(Vehiculo v1, Vehiculo v2) {
            return v1.getMarca().compareToIgnoreCase(v2.getMarca());
        }
    }
    
    public static class ComparadorPorAnio implements Comparator<Vehiculo> {

        @Override
        public int compare(Vehiculo v1, Vehiculo v2) {
            return Integer.compare(v1.getAnio(), v2.getAnio());
        }
    }
}
