package gestiondeveiculos.Enums;

public enum TipoCombustible {
    NAFTA,
    DIESEL,
    ELECTRICO,
    INDETERMINADO
}