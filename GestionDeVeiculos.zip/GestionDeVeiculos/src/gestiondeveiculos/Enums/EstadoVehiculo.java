package gestiondeveiculos.Enums;

public enum EstadoVehiculo {
    ACTIVO,
    INACTIVO,
    EN_REPARACION,
    INDETERMINADO
}
