package gestiondeveiculos;

import gestiondeveiculos.Enums.EstadoVehiculo;

public class Moto extends Vehiculo {

    private int cilindrada;
    private boolean tieneSidecar;

    public Moto(int id, String marca, int anio, EstadoVehiculo estado, int cilindrada, boolean tieneSidecar) {
        super(id, marca, anio, estado);
        this.cilindrada = cilindrada;
        this.tieneSidecar = tieneSidecar;
    }
    
    public Moto(int id, String marca, int anio, EstadoVehiculo estado) {
        super(id, marca, anio, estado);
        this.cilindrada = -1;
        this.tieneSidecar = false;
    }

    public Moto(int id) {
        super(id, "INDETERMINADA", 0, EstadoVehiculo.INDETERMINADO);
        this.cilindrada = -1;
        this.tieneSidecar = false;
    }

    @Override
    public double calcularImpuesto() {
        return cilindrada * 1.5;
    }

    @Override
    public String toString() {
        return "MOTO | " + super.toString() +
               " | Cilindrada: " + cilindrada +
               " | Sidecar: " + tieneSidecar;
    }
    
    public int getCilindrada() { return cilindrada; }
    public boolean getTieneSidecar() { return tieneSidecar; }
}
