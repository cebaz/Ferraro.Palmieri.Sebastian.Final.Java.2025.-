package gestiondeveiculos;
import gestiondeveiculos.Enums.EstadoVehiculo;
import java.io.Serializable;

public abstract class Vehiculo implements Serializable, Comparable<Vehiculo> {

    protected int id;
    protected String marca;
    protected int anio;
    protected EstadoVehiculo estado;

    public Vehiculo(int id, String marca, int anio, EstadoVehiculo estado) {
        this.id = id;
        this.marca = marca;
        this.anio = anio;
        this.estado = estado;
    }

    public Vehiculo(int id, String marca, int anio) {
        this(id, marca, anio, EstadoVehiculo.ACTIVO);
    }

    public Vehiculo(int id) {
        this(id, "Sin marca", 0, EstadoVehiculo.INACTIVO);
    }

    public abstract double calcularImpuesto();

    public String getDescripcion() {
        return marca + " (" + anio + ") - " + estado;
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Marca: " + marca +" | Año: " + anio +" | Estado: " + estado;
    }

    @Override
    public int compareTo(Vehiculo o) {
        return Integer.compare(this.id, o.id);
    }

    public int getId() { return id; }
    public String getMarca() { return marca; }
    public int getAnio() { return anio; }
    public EstadoVehiculo getEstado() { return estado; }

    public void setEstado(EstadoVehiculo estado) {
        this.estado = estado;
    }
}
