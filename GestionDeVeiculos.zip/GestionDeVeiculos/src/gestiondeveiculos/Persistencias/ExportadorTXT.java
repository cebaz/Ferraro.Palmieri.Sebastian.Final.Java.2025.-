package gestiondeveiculos.Persistencias;

import gestiondeveiculos.Vehiculo;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ExportadorTXT {

    public static void exportar(String ruta, List<? extends Vehiculo> lista) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {

            bw.write("Listado de Veiculos");
            bw.newLine();
            bw.newLine();

            for (Vehiculo v : lista) {
                bw.write(v.toString());
                bw.newLine();
            }

        } catch (IOException e) {
            throw new RuntimeException("Error al exportar TXT", e);
        }
    }
}
