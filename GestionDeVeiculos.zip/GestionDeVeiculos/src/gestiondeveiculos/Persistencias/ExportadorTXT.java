package gestiondeveiculos.Persistencias;

import gestiondeveiculos.Auto;
import gestiondeveiculos.Camion;
import gestiondeveiculos.Moto;
import gestiondeveiculos.Vehiculo;
import gestiondeveiculos.Excepciones;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ExportadorTXT {

    public static void exportar(String ruta, List<? extends Vehiculo> lista) throws Excepciones.PersistenciaException {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {

            bw.write("==== LISTADO DE VEHICULOS ====");
            bw.newLine();
            bw.newLine();

            for (Vehiculo v : lista) {
                
                
                if (v instanceof Auto a) {
                    escribirDatosVeiculoTXT(bw,"AUTO",a);
                    bw.write(" | Puertas: " + a.getPuertas() + " | Combustible: " + a.getCombustible());

                } else if (v instanceof Moto m) {
                    escribirDatosVeiculoTXT(bw,"MOTO",m);
                    bw.write("Cilindrada: " + m.getCilindrada()+ " | Sidecar: " + m.getTieneSidecar());

                } else if (v instanceof Camion c) {
                    escribirDatosVeiculoTXT(bw,"CAMION",c);
                    bw.write(" | Carga Max: " + c.getCargaMaxima()+ " | Ejes: " + c.getEjes());
                }

                bw.newLine();
            }

        } catch (IOException e) {
            throw new Excepciones.PersistenciaException("Error al guardar TXT", e);
        }
    }
    
    //datos que se comprarten entre veiculos
    private static void escribirDatosVeiculoTXT(BufferedWriter bw, String tipo, Vehiculo v)throws IOException {
        bw.write(tipo + " | ID: " + v.getId()+ " | Marca: " + v.getMarca()+ " | Anio: " + v.getAnio()+ " | Estado: " + v.getEstado());
    }
}