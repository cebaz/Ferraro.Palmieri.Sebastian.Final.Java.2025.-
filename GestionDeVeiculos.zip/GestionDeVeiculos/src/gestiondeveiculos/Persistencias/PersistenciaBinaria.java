package gestiondeveiculos.Persistencias;

import gestiondeveiculos.Vehiculo;
import java.io.*;
import java.util.List;

public class PersistenciaBinaria {

    public static void guardar(String ruta, List<? extends Vehiculo> lista) {
        try (ObjectOutputStream oos =
                     new ObjectOutputStream(new FileOutputStream(ruta))) {

            oos.writeObject(lista);

        } catch (IOException e) {
            throw new RuntimeException("Error al guardar archivo binario", e);
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Vehiculo> cargar(String ruta) {
        try (ObjectInputStream ois =
                     new ObjectInputStream(new FileInputStream(ruta))) {

            return (List<Vehiculo>) ois.readObject();

        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException("Error al leer archivo binario", e);
        }
    }
}
