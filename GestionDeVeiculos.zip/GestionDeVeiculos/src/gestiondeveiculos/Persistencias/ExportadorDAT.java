package gestiondeveiculos.Persistencias;

import java.io.*;
import java.util.List;
import gestiondeveiculos.Excepciones;
import gestiondeveiculos.Vehiculo;

public class ExportadorDAT {
    public static void exportar(String ruta, List<? extends Vehiculo> lista) throws Excepciones.PersistenciaException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
        } catch (IOException e) {
            throw new Excepciones.PersistenciaException("Error al guardar DAT", e);
        }
    }
}
