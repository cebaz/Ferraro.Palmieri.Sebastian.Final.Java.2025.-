package gestiondeveiculos.Persistencias;

import gestiondeveiculos.Auto;
import gestiondeveiculos.Camion;
import gestiondeveiculos.Enums.TipoCombustible;
import gestiondeveiculos.Enums.EstadoVehiculo;
import gestiondeveiculos.Excepciones;
import gestiondeveiculos.Moto;
import gestiondeveiculos.Vehiculo;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class PersistenciaJSON {

    public static void guardar(String ruta, List<? extends Vehiculo> lista) throws Excepciones.PersistenciaException{

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {

            bw.write("[\n");

            for (int i = 0; i < lista.size(); i++) {
                Vehiculo v = lista.get(i);

                bw.write("  {\n");

                if (v instanceof Auto a) {
                    escribirDatosVeiculoJSON(bw, "AUTO", a);
                    bw.write("    \"puertas\": " + a.getPuertas() + ",\n");
                    bw.write("    \"combustible\": \"" + a.getCombustible() + "\"\n");

                } else if (v instanceof Moto m) {
                    escribirDatosVeiculoJSON(bw, "MOTO", m);
                    bw.write("    \"cilindrada\": " + m.getCilindrada() + ",\n");
                    bw.write("    \"tieneSidecar\": " + m.getTieneSidecar() + "\n");

                } else if (v instanceof Camion c) {
                    escribirDatosVeiculoJSON(bw, "CAMION", c);
                    bw.write("    \"cargaMaxima\": " + c.getCargaMaxima() + ",\n");
                    bw.write("    \"ejes\": " + c.getEjes() + "\n");
                }

                bw.write("  }");

                if (i < lista.size() - 1) {
                    bw.write(",");
                }
                bw.write("\n");
            }

            bw.write("]");

        } catch (IOException e) {
            throw new Excepciones.PersistenciaException("Error al guardar JSON", e);
        }
    }
    
    private static void escribirDatosVeiculoJSON(BufferedWriter bw, String tipo, Vehiculo v)throws IOException {
        bw.write("    \"tipo\": \"" + tipo + "\",\n");
        bw.write("    \"id\": " + v.getId() + ",\n");
        bw.write("    \"marca\": \"" + v.getMarca() + "\",\n");
        bw.write("    \"anio\": " + v.getAnio() + ",\n");
        bw.write("    \"estado\": \"" + v.getEstado() + "\",\n");
    }

    
    public static List<Vehiculo> recuperar(String ruta) throws Excepciones.PersistenciaException{

        List<Vehiculo> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;

            String tipo = null;
            int id = 0;
            String marca = null;
            int anio = 0;
            EstadoVehiculo estado = null;
            //auto
            int puertas = -1;
            TipoCombustible combustible = TipoCombustible.INDETERMINADO;
            //moto
            int cilindrada = -1;
            boolean tieneSidecar = false;
            //camion
            double cargaMaxima = -1;
            int ejes = -1;

            while ((linea = br.readLine()) != null) {
                linea = linea.trim();

                if (linea.startsWith("\"tipo\""))
                    tipo = linea.split(":")[1].replace("\"", "").replace(",", "").trim();

                else if (linea.startsWith("\"id\""))
                    id = Integer.parseInt(linea.split(":")[1].replace(",", "").trim());

                else if (linea.startsWith("\"marca\""))
                    marca = linea.split(":")[1].replace("\"", "").replace(",", "").trim();

                else if (linea.startsWith("\"anio\""))
                    anio = Integer.parseInt(linea.split(":")[1].replace(",", "").trim());

                else if (linea.startsWith("\"estado\""))
                    estado = EstadoVehiculo.valueOf(
                            linea.split(":")[1].replace("\"", "").replace(",", "").trim()
                    );

                else if (linea.startsWith("\"puertas\""))
                    puertas = Integer.parseInt(linea.split(":")[1].replace(",", "").trim());

                else if (linea.startsWith("\"combustible\""))
                    combustible = TipoCombustible.valueOf(
                            linea.split(":")[1].replace("\"", "").replace(",", "").trim()
                    );

                else if (linea.startsWith("\"cilindrada\""))
                    cilindrada = Integer.parseInt(linea.split(":")[1].replace(",", "").trim());

                else if (linea.startsWith("\"tieneSidecar\""))
                    tieneSidecar = Boolean.parseBoolean(
                            linea.split(":")[1].replace(",", "").trim()
                    );

                else if (linea.startsWith("\"cargaMaxima\""))
                    cargaMaxima = Double.parseDouble(
                            linea.split(":")[1].replace(",", "").trim()
                    );

                else if (linea.startsWith("\"ejes\""))
                    ejes = Integer.parseInt(linea.split(":")[1].replace(",", "").trim());

                else if (linea.equals("},") | linea.equals("}")) {

                    Vehiculo v = null;

                    switch (tipo) {
                        case "AUTO":
                            v = new Auto(id, marca, anio, estado, puertas, combustible);
                            break;

                        case "MOTO":
                            v = new Moto(id, marca, anio, estado, cilindrada, tieneSidecar);
                            break;

                        case "CAMION":
                            v = new Camion(id, marca, anio, estado, cargaMaxima, ejes);
                            break;
                    }

                    if (v != null) {
                        lista.add(v);
                    }

                    //reset para el proximo objeto
                    puertas = -1;
                    combustible = TipoCombustible.INDETERMINADO;
                    cilindrada = -1;
                    tieneSidecar = false;
                    cargaMaxima = -1;
                    ejes = -1;
                }
            }
        } catch (IOException e) {
            throw new Excepciones.PersistenciaException("Error al recuperar JSON", e);
        }
        return lista;
    }
}
