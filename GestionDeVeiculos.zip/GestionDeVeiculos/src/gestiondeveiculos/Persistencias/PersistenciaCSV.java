package gestiondeveiculos.Persistencias;

import gestiondeveiculos.Auto;
import gestiondeveiculos.Camion;
import gestiondeveiculos.Enums.TipoCombustible;
import gestiondeveiculos.Enums.EstadoVehiculo;
import gestiondeveiculos.Excepciones;
import gestiondeveiculos.Moto;
import gestiondeveiculos.Vehiculo;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PersistenciaCSV {

    public static void guardar(String ruta, List<? extends Vehiculo> lista) throws Excepciones.PersistenciaException{

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {

            bw.write("tipo,id,marca,anio,estado,extra1,extra2");
            bw.newLine();

            for (Vehiculo v : lista) {

                if (v instanceof Auto a) {
                    escribirDatosVeiculoCSV(bw, "AUTO", a);
                    bw.write(a.getPuertas() + ",");
                    bw.write("" + a.getCombustible());

                } else if (v instanceof Moto m) {
                    escribirDatosVeiculoCSV(bw, "MOTO", m);
                    bw.write(m.getCilindrada() + ",");
                    bw.write("" + m.getTieneSidecar());

                } else if (v instanceof Camion c) {
                    escribirDatosVeiculoCSV(bw, "CAMION", c);
                    bw.write(c.getCargaMaxima() + ",");
                    bw.write("" + c.getEjes());
                }
                bw.newLine();
            }


        } catch (IOException e) {
            throw new Excepciones.PersistenciaException("Error al guardar CSV", e);
        }
    }
    
    private static void escribirDatosVeiculoCSV(BufferedWriter bw, String tipo, Vehiculo v)throws IOException {
        bw.write(tipo + ",");
        bw.write(v.getId() + ",");
        bw.write(v.getMarca() + ",");
        bw.write(v.getAnio() + ",");
        bw.write(v.getEstado() + ",");
    }

    public static List<Vehiculo> recuperar(String ruta) throws Excepciones.PersistenciaException{

        List<Vehiculo> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {

            String linea;
            boolean primera = true;

            while ((linea = br.readLine()) != null) {

                if (primera) {
                    primera = false;
                    continue;
                }

                String[] partes = linea.split(",");

                String tipo = partes[0];
                int id = Integer.parseInt(partes[1]);
                String marca = partes[2];
                int anio = Integer.parseInt(partes[3]);
                EstadoVehiculo estado = EstadoVehiculo.valueOf(partes[4]);

                Vehiculo v = null;

                switch (tipo) {
                    case "AUTO": {
                        int puertas = Integer.parseInt(partes[5]);
                        TipoCombustible combustible =
                                TipoCombustible.valueOf(partes[6]);

                        v = new Auto(id, marca, anio, estado, puertas, combustible);
                        break;
                    }

                    case "MOTO": {
                        int cilindrada = Integer.parseInt(partes[5]);
                        boolean tieneSidecar = Boolean.parseBoolean(partes[6]);

                        v = new Moto(id, marca, anio, estado, cilindrada, tieneSidecar);
                        break;
                    }

                    case "CAMION": {
                        double cargaMaxima = Double.parseDouble(partes[5]);
                        int ejes = Integer.parseInt(partes[6]);

                        v = new Camion(id, marca, anio, estado, cargaMaxima, ejes);
                        break;
                    }
                }

                if (v != null) {
                    lista.add(v);
                }
            }

        } catch (IOException e) {
            throw new Excepciones.PersistenciaException("Error al recuperar CSV", e);
        }

        return lista;
    }

}
