package gestiondeveiculos;

public class Excepciones {

    public static class VehiculoNoEncontradoException extends RuntimeException {
        public VehiculoNoEncontradoException(int id) {
            super("No se encontro el vehiculo con id: " + id);
        }
    }
    
    //excepcion para los archivos
    public static class PersistenciaException extends Exception {
        public PersistenciaException(String mensaje, Throwable causa) {
            super(mensaje, causa);
        }
    }
}
