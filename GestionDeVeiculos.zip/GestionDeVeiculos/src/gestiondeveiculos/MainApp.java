package gestiondeveiculos;

import gestiondeveiculos.Persistencias.PersistenciaJSON;
import gestiondeveiculos.Persistencias.PersistenciaCSV;
import gestiondeveiculos.Enums.TipoCombustible;
import gestiondeveiculos.Enums.EstadoVehiculo;
import java.util.Comparator;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.List;

public class MainApp extends Application {

    private final GestionDeVeiculos<Vehiculo> gestor = new GestionDeVeiculos<>();
    private final TableView<Vehiculo> tabla = new TableView<>();

    @Override
    public void start(Stage stage) {

        // columnas
        TableColumn<Vehiculo, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(v -> new javafx.beans.property.SimpleIntegerProperty(v.getValue().getId()).asObject());
        
        TableColumn<Vehiculo, String> colTipo = new TableColumn<>("Tipo");
        colTipo.setCellValueFactory(v ->new javafx.beans.property.SimpleStringProperty(v.getValue().getClass().getSimpleName()));

        TableColumn<Vehiculo, String> colMarca = new TableColumn<>("Marca");
        colMarca.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getMarca()));

        TableColumn<Vehiculo, Integer> colAnio = new TableColumn<>("Anio");
        colAnio.setCellValueFactory(v -> new javafx.beans.property.SimpleIntegerProperty(v.getValue().getAnio()).asObject());

        TableColumn<Vehiculo, String> colEstado = new TableColumn<>("Estado");
        colEstado.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getEstado().toString()));

        tabla.getColumns().addAll(colId, colTipo, colMarca, colAnio, colEstado);

        //imputs
        TextField tfId = new TextField();
        tfId.setPromptText("ID");

        TextField tfMarca = new TextField();
        tfMarca.setPromptText("Marca");

        TextField tfAnio = new TextField();
        tfAnio.setPromptText("Anio");

        ComboBox<EstadoVehiculo> cbEstado = new ComboBox<>();
        cbEstado.getItems().addAll(EstadoVehiculo.values());
        cbEstado.setValue(EstadoVehiculo.INDETERMINADO);

        ComboBox<String> cbTipo = new ComboBox<>();
        cbTipo.getItems().addAll("AUTO", "MOTO", "CAMION");
        cbTipo.setValue("AUTO");

        //botones
        Button btnAgregar = new Button("Agregar");
        Button btnEliminar = new Button("Eliminar");

        btnAgregar.setOnAction(e -> {
            try {
                int id = Integer.parseInt(tfId.getText());
                int anio = Integer.parseInt(tfAnio.getText());
                String marca = tfMarca.getText();
                EstadoVehiculo estado = cbEstado.getValue();

                Vehiculo v;

                switch (cbTipo.getValue()) {
                    case "MOTO":
                        v = new Moto(id, marca, anio, estado, -1, false);
                        break;
                    case "CAMION":
                        v = new Camion(id, marca, anio, estado, -1, -1);
                        break;
                    default:
                        v = new Auto(id, marca, anio, estado, -1, TipoCombustible.INDETERMINADO);
                }

                gestor.agregar(v);
                refrescarTabla();

            } catch (Exception ex) {
                mostrarError(ex.getMessage());
            }
        });

        btnEliminar.setOnAction(e -> {
            Vehiculo v = tabla.getSelectionModel().getSelectedItem();
            if (v != null) {
                gestor.eliminar(v.getId());
                refrescarTabla();
            }
        });

        //ordenar
        Button btnOrdenar = new Button("Ordenar por Marca");
        btnOrdenar.setOnAction(e -> {
            gestor.ordenarConComparator((Comparator) new GestionDeVeiculos.ComparadorPorMarca());
            refrescarTabla();
        });

        //filtrar
        ComboBox<EstadoVehiculo> fcbFiltarEstado = new ComboBox<>();
        fcbFiltarEstado.getItems().addAll(EstadoVehiculo.values());
        fcbFiltarEstado.setValue(EstadoVehiculo.ACTIVO);

        Button btnFiltrar = new Button("Filtrar");
        btnFiltrar.setOnAction(e -> {
            List<Vehiculo> filtrados = UtilVehiculos.filtrarPorEstado(gestor.listar(), fcbFiltarEstado.getValue());
            tabla.getItems().setAll(filtrados);
        });
        
        //des-filtrar
        Button btnDesFiltro = new Button("X");
        btnDesFiltro.setOnAction(e -> {
            refrescarTabla();
        });



        //Cambiar estado
        ComboBox<EstadoVehiculo> cbCambiarEstado = new ComboBox<>();
        cbCambiarEstado.getItems().addAll(EstadoVehiculo.values());
        cbCambiarEstado.setValue(EstadoVehiculo.INDETERMINADO);
        
        Button btnCambiarEstado = new Button("Cambiar estado");

        btnCambiarEstado.setOnAction(e -> {
            Vehiculo seleccionado = tabla.getSelectionModel().getSelectedItem();
            EstadoVehiculo nuevoEstado = cbCambiarEstado.getValue();

            if (seleccionado != null && nuevoEstado != null) {

                gestor.aplicarConsumer(v -> {
                    if (v.getId() == seleccionado.getId()) {
                        v.setEstado(nuevoEstado);
                    }
                });
                refrescarTabla();
            }
        });


        // ---------- PERSISTENCIA ----------
        Button btnGuardarCSV = new Button("Guardar CSV");
        Button btnCargarCSV = new Button("Cargar CSV");
        Button btnGuardarJSON = new Button("Guardar JSON");
        Button btnCargarJSON = new Button("Cargar JSON");

        btnGuardarCSV.setOnAction(e -> {
            try {
                PersistenciaCSV.guardar("vehiculos.csv", gestor.listar());
            } catch (Excepciones.PersistenciaException ex) {
                mostrarError(ex.getMessage());
            }
        });

        btnCargarCSV.setOnAction(e -> {
            try {
                gestor.reemplazarLista(PersistenciaCSV.recuperar("vehiculos.csv"));
                refrescarTabla();
            } catch (Excepciones.PersistenciaException ex) {
                mostrarError(ex.getMessage());
            }
        });

        btnGuardarJSON.setOnAction(e -> {
            try {
                PersistenciaJSON.guardar("vehiculos.json", gestor.listar());
            } catch (Excepciones.PersistenciaException ex) {
                mostrarError(ex.getMessage());
            }
        });

        btnCargarJSON.setOnAction(e -> {
            try {
                gestor.reemplazarLista(PersistenciaJSON.recuperar("vehiculos.json"));
                refrescarTabla();
            } catch (Excepciones.PersistenciaException ex) {
                mostrarError(ex.getMessage());
            }
        });

        //mostrar
        HBox fila1 = new HBox(5, tfId, tfMarca, tfAnio, cbEstado, cbTipo, btnAgregar, btnEliminar);
        HBox fila2 = new HBox(5, btnOrdenar, fcbFiltarEstado, btnFiltrar, btnDesFiltro);
        HBox fila3 = new HBox(5, btnOrdenar, cbCambiarEstado, btnCambiarEstado);
        HBox fila4 = new HBox(5, btnGuardarCSV, btnCargarCSV);
        HBox fila5 = new HBox(5, btnGuardarJSON, btnCargarJSON);

        VBox root = new VBox(10, tabla, fila1, fila2, fila3, fila4, fila5);

        stage.setScene(new Scene(root, 900, 500));
        stage.setTitle("Gestion de Vehiculos");
        stage.show();
    }

    private void refrescarTabla() {
        tabla.getItems().setAll(gestor.listar());
    }

    private void mostrarError(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR, mensaje);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch();
    }
}
