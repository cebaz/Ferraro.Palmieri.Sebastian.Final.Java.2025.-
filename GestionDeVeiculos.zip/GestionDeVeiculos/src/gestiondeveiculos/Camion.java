package gestiondeveiculos;

import gestiondeveiculos.Enums.EstadoVehiculo;
import gestiondeveiculos.Interfaces.Asegurable;

public class Camion extends Vehiculo implements Asegurable{

    private double cargaMaxima;
    private int ejes;

    public Camion(int id, String marca, int anio, EstadoVehiculo estado, double cargaMaxima, int ejes) {
        super(id, marca, anio, estado);
        this.cargaMaxima = cargaMaxima;
        this.ejes = ejes;
    }
    
    public Camion(int id, String marca, int anio, EstadoVehiculo estado) {
        super(id, marca, anio, estado);
        this.cargaMaxima = -1;
        this.ejes = -1;
    }

    public Camion(int id) {
        super(id, "INDETERMINADA", 0, EstadoVehiculo.INDETERMINADO);
        this.cargaMaxima = -1;
        this.ejes = -1;
    }

    @Override
    public double calcularImpuesto() {
        return cargaMaxima * 0.8;
    }
    
    @Override
    public double calcularSeguro() {
        double base = 30000;
        base += (ejes * 2000);
        base += (cargaMaxima * 0.5);
        return base;
    }

    @Override
    public String toString() {
        return "CAMION | " + super.toString() + " | Carga Máx: " + cargaMaxima + " | Ejes: " + ejes;
    }
    
    public double getCargaMaxima() { return cargaMaxima; }
    public int getEjes() { return ejes; }
}
