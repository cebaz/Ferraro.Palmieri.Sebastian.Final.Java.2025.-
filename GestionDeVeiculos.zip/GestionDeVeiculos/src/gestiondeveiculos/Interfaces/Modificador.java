package gestiondeveiculos.Interfaces;

@FunctionalInterface
public interface Modificador<T> {
    void aplicar(T elemento);
}
