package gestiondeveiculos.Interfaces;

public interface Asegurable {
    double calcularSeguro();
}
