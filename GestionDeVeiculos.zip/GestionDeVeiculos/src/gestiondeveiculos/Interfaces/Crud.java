package gestiondeveiculos.Interfaces;

import java.util.List;

public interface Crud<T> {

    void agregar(T elemento);

    void eliminar(int id);

    T buscar(int id);

    List<T> listar();
}
