package gestiondeveiculos;

import gestiondeveiculos.Enums.TipoCombustible;
import gestiondeveiculos.Enums.EstadoVehiculo;
import gestiondeveiculos.Interfaces.Asegurable;

public class Auto extends Vehiculo implements Asegurable{

    private int puertas;
    private TipoCombustible combustible;

    public Auto(int id, String marca, int anio, EstadoVehiculo estado, int puertas, TipoCombustible combustible) {
        super(id, marca, anio, estado);
        this.puertas = puertas;
        this.combustible = combustible;
    }
    
    public Auto(int id, String marca, int anio, EstadoVehiculo estado) {
        super(id, marca, anio, estado);
        this.puertas = -1;
        this.combustible = TipoCombustible.INDETERMINADO;
    }
    
    public Auto(int id) {
        super(id, "INDETERMINADA", 0, EstadoVehiculo.INDETERMINADO);
        this.puertas = -1;
        this.combustible = TipoCombustible.INDETERMINADO;
    }


    @Override
    public double calcularImpuesto() {
        return 1000 + (anio * 2);
    }
    
    @Override
    public double calcularSeguro() {
        double base = 15000;
        if (combustible == TipoCombustible.ELECTRICO) {
            base += 3000;
        }
        if (anio < 2015) {
            base += 2000;
        }
        return base;
    }

    @Override
    public String toString() {
        return "AUTO | " + super.toString() +
               " | Puertas: " + puertas +
               " | Combustible: " + combustible;
    }
    
    public int getPuertas() { return puertas; }
    public TipoCombustible getCombustible() { return combustible; }
}
